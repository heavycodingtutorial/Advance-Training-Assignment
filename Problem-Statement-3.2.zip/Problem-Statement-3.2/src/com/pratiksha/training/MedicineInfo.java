package com.pratiksha.training;

public interface MedicineInfo {
	void displayLabel();
}
